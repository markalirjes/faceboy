<?php
$mysqli = new mysqli("localhost", "root", "", "image_db");

function getRandomImages($mysqli) {
    $result = $mysqli->query("SELECT * FROM images ORDER BY RAND() LIMIT 2");
    $images = $result->fetch_all(MYSQLI_ASSOC);
    if ($images[0]['id'] == $images[1]['id']) {
        return getRandomImages($mysqli);
    }
    return $images;
}

if (isset($_GET['clicked'])) {
    $clickedId = $_GET['clicked'];
    $mysqli->query("UPDATE images SET valid = valid + 1 WHERE id = $clickedId");
}

$images = getRandomImages($mysqli);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Face boy</title>
    <style>
        body {
	font-family: Tahoma;
	margin: 0;
	padding: 0;
	text-align: center;
}
a {
	text-decoration: none;
	color: darkblue;
}
a:hover {
	text-decoration: underline;
}
img {
	width: 175px;
	height: 250px;
	border: 2px solid #aaa;
}
#header {
	background-color: #8C1B08;
	color: #fff;
	padding: 5px;
}
#header a{
	color: #fff;
	text-decoration: none;
}
#main table {
	margin: 0 auto;
}
#footer {
	font: 12px Tahoma;
	margin: 25px 0 50px 0;
}
#footer a {
	margin-right: 10px;
}
    </style>
</head>
<body>
    <div id="header">
    <h1><a href="index.php">FACEBOY</a></h1>
    </div>
    <div id="main">
	<h3>Were we let in for our looks? No. Will we be judged on them? Yes.</h3>
	<h2>Who's Hotter? Click to Choose.</h2>
	<table>
		<tr>
    <td>
    <a href="?clicked=<?php echo $images[0]['id']; ?>">
            <img src="<?php echo $images[0]['image_path']; ?>" width="200">
        </a>
    </td>
    <td>OR</td>
    <td>
        <a href="?clicked=<?php echo $images[1]['id']; ?>">
            <img src="<?php echo $images[1]['image_path']; ?>" width="200">
        </a>
    </td>
		</tr>
	</table>
</div>
<div id="footer">
	<a href="#">POWERED BY : MARK ALIRJES</a>
	<br />
	<a href="index.php">Home</a>
	<a href="about.html">About</a>
	<a href="submit.html">Submit</a>
	<a href="rankings.html">Rankings</a>
</div>
</body>
</html>
